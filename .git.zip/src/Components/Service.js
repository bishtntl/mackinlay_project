

import React from "react";
import "../Css/styletwo.css";
import custom_soft_dev from "../Assetes/images/custom_soft_dev.png";
import cloud_comp_sol from "../Assetes/images/Cloud_Computing_Solutions.png";
import web_dev_and_design from "../Assetes/images/Web_Development_Design.png";
import mobile_app_dev from "../Assetes/images/mobile_app_dev.png";
import data_analytics from "../Assetes/images/Data_analytics.png";
import FooterCompo from "./Footer";

function Service() {
  return (
    <>
      <section class="container" id="latestjobopening">
        <div class="row mt-5">
          <div class="col-md-11 mx-auto">
            <div class="service-title">
              <p>
                C<span>onsulting</span> S<span>ervices</span>
              </p>
              <p>Our Services</p>
            </div>

            <div class="owl-carousel letest mx-auto">
              <div class="item ">
                <div class="post-slide">

                    <div class="custom-img-div">
                      <img src={custom_soft_dev} alt="not found" />
                    </div>
                    <div class="service-type-title">
                      Custom Software Development
                    </div>
                    <div class="">
                      <p class="service-type-detail">
                        Transform your HR and insurance operations with our
                        bespoke software solutions ,meticulously crafted to
                        streamline processes, enhance productivity, and improve
                        overall efficiency.
                      </p>
                      <a href="" className="read-more">Read more</a>
                    </div>

                </div>
              </div>
              <div class="item ">
                <div class="post-slide">

                    <div class="custom-img-div">
                      <img src={cloud_comp_sol} alt="not found" />
                    </div>
                    <div class="service-type-title">
                      Cloud Computing Solutions
                    </div>
                    <div class="">
                      <p class="service-type-detail">
                        Unlock the power of the cloud with our scalable and
                        secure cloud computing solutions.
                      </p>
                      <a href="" class="read-more">Read more</a>
                    </div>
                </div>
              </div>
              <div class="item">
                <div class="post-slide">
                    <div class="custom-img-div">
                      <img src={web_dev_and_design} alt="not found" />
                    </div>
                    <div class="service-type-title">
                      Web Development and Design
                    </div>
                    <div class="">
                      <p class="service-type-detail">
                        Elevate your online presence with our expertly designed
                        websites and optimized.
                      </p>
                      <a href="" class="read-more">Read more</a>
                    </div>
                </div>
              </div>
              <div class="item ">
                <div class="post-slide">
                    <div class="custom-img-div">
                      <img src={mobile_app_dev} alt="not found" />
                    </div>
                    <div class="service-type-title">Mobile App Development</div>
                    <div class="">
                      <p class="service-type-detail">
                        Mobile applications designed to deliver a superior user
                        experience and drive engagement.
                      </p>
                      <a href="" class="read-more">Read more</a>
                    </div>
                </div>
              </div>
            </div>

             <div class="owl-carousel service mx-auto">
              <div class="item ">
                <div class="post-slide">

                    <div class="custom-img-div">
                      <img src={custom_soft_dev} alt="not found" />
                    </div>
                    <div class="service-type-title">
                      Custom Software Development
                    </div>
                    <div class="">
                      <p class="service-type-detail">
                        Transform your HR and insurance operations with our
                        bespoke software solutions ,meticulously crafted to
                        streamline processes, enhance productivity, and improve
                        overall efficiency.
                      </p>
                      <a href="" className="read-more">Read more</a>
                    </div>

                </div>
              </div>
              <div class="item ">
                <div class="post-slide">

                    <div class="custom-img-div">
                      <img src={cloud_comp_sol} alt="not found" />
                    </div>
                    <div class="service-type-title">
                      Cloud Computing Solutions
                    </div>
                    <div class="">
                      <p class="service-type-detail">
                        Unlock the power of the cloud with our scalable and
                        secure cloud computing solutions.
                      </p>
                      <a href="" class="read-more">Read more</a>
                    </div>
                </div>
              </div>
              <div class="item">
                <div class="post-slide">
                    <div class="custom-img-div">
                      <img src={web_dev_and_design} alt="not found" />
                    </div>
                    <div class="service-type-title">
                      Web Development and Design
                    </div>
                    <div class="">
                      <p class="service-type-detail">
                        Elevate your online presence with our expertly designed
                        websites and optimized.
                      </p>
                      <a href="" class="read-more">Read more</a>
                    </div>
                </div>
              </div>
              <div class="item ">
                <div class="post-slide">
                    <div class="custom-img-div">
                      <img src={mobile_app_dev} alt="not found" />
                    </div>
                    <div class="service-type-title">Mobile App Development</div>
                    <div class="">
                      <p class="service-type-detail">
                        Mobile applications designed to deliver a superior user
                        experience and drive engagement.
                      </p>
                      <a href="" class="read-more">Read more</a>
                    </div>
                </div>
              </div>
            </div>
            <div class="owl-carousel service_two mx-auto">
              <div class="item ">
                <div class="post-slide">

                    <div class="custom-img-div">
                      <img src={custom_soft_dev} alt="not found" />
                    </div>
                    <div class="service-type-title">
                      Custom Software Development
                    </div>
                    <div class="">
                      <p class="service-type-detail">
                        Transform your HR and insurance operations with our
                        bespoke software solutions ,meticulously crafted to
                        streamline processes, enhance productivity, and improve
                        overall efficiency.
                      </p>
                      <a href="" className="read-more">Read more</a>
                    </div>

                </div>
              </div>
              <div class="item ">
                <div class="post-slide">

                    <div class="custom-img-div">
                      <img src={cloud_comp_sol} alt="not found" />
                    </div>
                    <div class="service-type-title">
                      Cloud Computing Solutions
                    </div>
                    <div class="">
                      <p class="service-type-detail">
                        Unlock the power of the cloud with our scalable and
                        secure cloud computing solutions.
                      </p>
                      <a href="" class="read-more">Read more</a>
                    </div>
                </div>
              </div>
              <div class="item">
                <div class="post-slide">
                    <div class="custom-img-div">
                      <img src={web_dev_and_design} alt="not found" />
                    </div>
                    <div class="service-type-title">
                      Web Development and Design
                    </div>
                    <div class="">
                      <p class="service-type-detail">
                        Elevate your online presence with our expertly designed
                        websites and optimized.
                      </p>
                      <a href="" class="read-more">Read more</a>
                    </div>
                </div>
              </div>
              <div class="item ">
                <div class="post-slide">
                    <div class="custom-img-div">
                      <img src={mobile_app_dev} alt="not found" />
                    </div>
                    <div class="service-type-title">Mobile App Development</div>
                    <div class="">
                      <p class="service-type-detail">
                        Mobile applications designed to deliver a superior user
                        experience and drive engagement.
                      </p>
                      <a href="" class="read-more">Read more</a>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <FooterCompo/>
    </>
  );
}

export default Service;




// import React from "react";
// import custom_soft_dev from "../Assetes/images/custom_soft_dev.png";

// function Home() {
//   return (
//     <div>
//       <h1>Home</h1>

//       <section class="container" id="latestjobopening">
//         <div class="row">
//           <div class="col-md-11 mx-auto">
//             <div class="job-category">
//               <p>Our Best Services</p>
//             </div>

//             <div class="owl-carousel letest mx-auto">
//               <div class="item p-2">
//                 <div class="post-slide">
//                   <div class=" ">
//                     <div>
//                       <img src={custom_soft_dev} alt="not found" />
//                     </div>
//                     <div class="ui-ux-para ps-2 ">
//                       Custom Software Development
//                     </div>
//                     <div class="">
//                       <p class="ui-ux-para pb-3 pt-3">
//                         Transform your HR and insurance operations with our
//                         bespoke software solutions.
//                       </p>
//                       <a href="">Read more</a>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div class="item p-2">
//                 <div class="post-slide">
//                   <div class=" ">
//                     <div>
//                       <img src={custom_soft_dev} alt="not found" />
//                     </div>
//                     <div class="ui-ux-para ps-2 ">
//                       Cloud Computing Solutions
//                     </div>
//                     <div class="">
//                       <p class="ui-ux-para pb-3 pt-3">
//                         Unlock the power of the cloud with our scalable and
//                         secure cloud computing solutions.
//                       </p>
//                       <a href="">Read more</a>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div class="item p-2">
//                 <div class="post-slide">
//                   <div class=" ">
//                     <div>
//                       <img src={custom_soft_dev} alt="not found" />
//                     </div>
//                     <div class="ui-ux-para ps-2 ">
//                       Custom Software Development
//                     </div>
//                     <div class="">
//                       <p class="ui-ux-para pb-3 pt-3">
//                         Transform your HR and insurance operations with our
//                         bespoke software solutions.
//                       </p>
//                       <a href="">Read more</a>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div class="item p-2">
//                 <div class="post-slide">
//                   <div class=" ">
//                     <div>
//                       <img src={custom_soft_dev} alt="not found" />
//                     </div>
//                     <div class="ui-ux-para ps-2 ">
//                       Cloud Computing Solutions
//                     </div>
//                     <div class="">
//                       <p class="ui-ux-para pb-3 pt-3">
//                         Unlock the power of the cloud with our scalable and
//                         secure cloud computing solutions.
//                       </p>
//                       <a href="">Read more</a>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div class="item p-2">
//                 <div class="post-slide">
//                   <div class=" ">
//                     <div>
//                       <img src={custom_soft_dev} alt="not found" />
//                     </div>
//                     <div class="ui-ux-para ps-2 ">
//                       Custom Software Development
//                     </div>
//                     <div class="">
//                       <p class="ui-ux-para pb-3 pt-3">
//                         Transform your HR and insurance operations with our
//                         bespoke software solutions.
//                       </p>
//                       <a href="">Read more</a>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div class="item p-2">
//                 <div class="post-slide">
//                   <div class=" ">
//                     <div>
//                       <img src={custom_soft_dev} alt="not found" />
//                     </div>
//                     <div class="ui-ux-para ps-2 ">
//                       Cloud Computing Solutions
//                     </div>
//                     <div class="">
//                       <p class="ui-ux-para pb-3 pt-3">
//                         Unlock the power of the cloud with our scalable and
//                         secure cloud computing solutions.
//                       </p>
//                       <a href="">Read more</a>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//             <div class="owl-carousel service mx-auto">
//               <div class="item p-2">
//                 <div class="post-slide">
//                   <div class=" ">
//                     <div>
//                       <img src={custom_soft_dev} alt="not found" />
//                     </div>
//                     <div class="ui-ux-para ps-2 ">
//                       Custom Software Development
//                     </div>
//                     <div class="">
//                       <p class="ui-ux-para pb-3 pt-3">
//                         Transform your HR and insurance operations with our
//                         bespoke software solutions.
//                       </p>
//                       <a href="">Read more</a>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div class="item p-2">
//                 <div class="post-slide">
//                   <div class=" ">
//                     <div>
//                       <img src={custom_soft_dev} alt="not found" />
//                     </div>
//                     <div class="ui-ux-para ps-2 ">
//                       Cloud Computing Solutions
//                     </div>
//                     <div class="">
//                       <p class="ui-ux-para pb-3 pt-3">
//                         Unlock the power of the cloud with our scalable and
//                         secure cloud computing solutions.
//                       </p>
//                       <a href="">Read more</a>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div class="item p-2">
//                 <div class="post-slide">
//                   <div class=" ">
//                     <div>
//                       <img src={custom_soft_dev} alt="not found" />
//                     </div>
//                     <div class="ui-ux-para ps-2 ">
//                       Custom Software Development
//                     </div>
//                     <div class="">
//                       <p class="ui-ux-para pb-3 pt-3">
//                         Transform your HR and insurance operations with our
//                         bespoke software solutions.
//                       </p>
//                       <a href="">Read more</a>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div class="item p-2">
//                 <div class="post-slide">
//                   <div class=" ">
//                     <div>
//                       <img src={custom_soft_dev} alt="not found" />
//                     </div>
//                     <div class="ui-ux-para ps-2 ">
//                       Cloud Computing Solutions
//                     </div>
//                     <div class="">
//                       <p class="ui-ux-para pb-3 pt-3">
//                         Unlock the power of the cloud with our scalable and
//                         secure cloud computing solutions.
//                       </p>
//                       <a href="">Read more</a>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div class="item p-2">
//                 <div class="post-slide">
//                   <div class=" ">
//                     <div>
//                       <img src={custom_soft_dev} alt="not found" />
//                     </div>
//                     <div class="ui-ux-para ps-2 ">
//                       Custom Software Development
//                     </div>
//                     <div class="">
//                       <p class="ui-ux-para pb-3 pt-3">
//                         Transform your HR and insurance operations with our
//                         bespoke software solutions.
//                       </p>
//                       <a href="">Read more</a>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div class="item p-2">
//                 <div class="post-slide">
//                   <div class=" ">
//                     <div>
//                       <img src={custom_soft_dev} alt="not found" />
//                     </div>
//                     <div class="ui-ux-para ps-2 ">
//                       Cloud Computing Solutions
//                     </div>
//                     <div class="">
//                       <p class="ui-ux-para pb-3 pt-3">
//                         Unlock the power of the cloud with our scalable and
//                         secure cloud computing solutions.
//                       </p>
//                       <a href="">Read more</a>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//             <div class="owl-carousel service_two mx-auto">
//               <div class="item p-2">
//                 <div class="post-slide">
//                   <div class=" ">
//                     <div>
//                       <img src={custom_soft_dev} alt="not found" />
//                     </div>
//                     <div class="ui-ux-para ps-2 ">
//                       Custom Software Development
//                     </div>
//                     <div class="">
//                       <p class="ui-ux-para pb-3 pt-3">
//                         Transform your HR and insurance operations with our
//                         bespoke software solutions.
//                       </p>
//                       <a href="">Read more</a>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div class="item p-2">
//                 <div class="post-slide">
//                   <div class=" ">
//                     <div>
//                       <img src={custom_soft_dev} alt="not found" />
//                     </div>
//                     <div class="ui-ux-para ps-2 ">
//                       Cloud Computing Solutions
//                     </div>
//                     <div class="">
//                       <p class="ui-ux-para pb-3 pt-3">
//                         Unlock the power of the cloud with our scalable and
//                         secure cloud computing solutions.
//                       </p>
//                       <a href="">Read more</a>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div class="item p-2">
//                 <div class="post-slide">
//                   <div class=" ">
//                     <div>
//                       <img src={custom_soft_dev} alt="not found" />
//                     </div>
//                     <div class="ui-ux-para ps-2 ">
//                       Custom Software Development
//                     </div>
//                     <div class="">
//                       <p class="ui-ux-para pb-3 pt-3">
//                         Transform your HR and insurance operations with our
//                         bespoke software solutions.
//                       </p>
//                       <a href="">Read more</a>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div class="item p-2">
//                 <div class="post-slide">
//                   <div class=" ">
//                     <div>
//                       <img src={custom_soft_dev} alt="not found" />
//                     </div>
//                     <div class="ui-ux-para ps-2 ">
//                       Cloud Computing Solutions
//                     </div>
//                     <div class="">
//                       <p class="ui-ux-para pb-3 pt-3">
//                         Unlock the power of the cloud with our scalable and
//                         secure cloud computing solutions.
//                       </p>
//                       <a href="">Read more</a>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div class="item p-2">
//                 <div class="post-slide">
//                   <div class=" ">
//                     <div>
//                       <img src={custom_soft_dev} alt="not found" />
//                     </div>
//                     <div class="ui-ux-para ps-2 ">
//                       Custom Software Development
//                     </div>
//                     <div class="">
//                       <p class="ui-ux-para pb-3 pt-3">
//                         Transform your HR and insurance operations with our
//                         bespoke software solutions.
//                       </p>
//                       <a href="">Read more</a>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div class="item p-2">
//                 <div class="post-slide">
//                   <div class=" ">
//                     <div>
//                       <img src={custom_soft_dev} alt="not found" />
//                     </div>
//                     <div class="ui-ux-para ps-2 ">
//                       Cloud Computing Solutions
//                     </div>
//                     <div class="">
//                       <p class="ui-ux-para pb-3 pt-3">
//                         Unlock the power of the cloud with our scalable and
//                         secure cloud computing solutions.
//                       </p>
//                       <a href="">Read more</a>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//             <form class="d-flex justify-content-center mt-4 mb-5">
//               <button class="btn more-btn " type="submit">
//                 more
//               </button>
//             </form>
//           </div>
//         </div>
//       </section>
//     </div>
//   );
// }

// export default Home;
